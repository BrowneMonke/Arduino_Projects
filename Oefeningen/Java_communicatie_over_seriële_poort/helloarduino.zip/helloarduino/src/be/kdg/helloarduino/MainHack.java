package be.kdg.helloarduino;

public class MainHack {
    public static void main(String[] args) {
        Main.main(args);
    }
}
